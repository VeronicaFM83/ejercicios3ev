package fp.daw.exprog20210616.ejercicio4;

import java.util.LinkedList;
import java.util.Queue;

public class Ejercicio4 {
	public static Queue intercalar(Queue<Integer> cola) {
		int tamanio = cola.size();
		int mitad;
		Queue<Integer> cola2 = new LinkedList<Integer>();
		if (cola.size() % 2 == 0) {
			mitad = tamanio/2;
			int contador = 0;
			while (!cola.isEmpty()) {
				contador++;
				if (contador == 1 || contador == (mitad+1)) {
					cola2.offer(cola.poll());

				} else {
					cola.offer(cola.poll());
				}
				if (contador == (tamanio)) {
					contador = 0;
					tamanio = tamanio-2;
					mitad = tamanio/2;
				}
				//System.out.println("vuelta " + contador + ": " + cola);
			}

		} else {
			throw new IllegalArgumentException("La cola no es par");
		}

		return cola2;
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Integer> cola = new LinkedList<Integer>();
		cola.offer(1);
		cola.offer(2);
		cola.offer(3);
		cola.offer(4);
		cola.offer(5);
		cola.offer(6);
		cola.offer(7);
		cola.offer(8);
		cola.offer(9);
		cola.offer(10);
		System.out.println(intercalar(cola));
	}

}
