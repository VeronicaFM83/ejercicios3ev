package fp.daw.exprog20210616.ejercicio3;

import java.io.IOException;

public class Prueba {

	public static void main(String[] args) {

		String ruta = "C:\\Users\\alumno\\Downloads\\pm2018.csv";
		try {
			ParqueMovil prueba = new ParqueMovil(ruta, 2018);
			prueba.guardaFichero("C:\\Users\\alumno\\Downloads\\prueba.dat");
			System.out.println(prueba.getTotalVehiculos("TURISMOS"));
			System.out.println(prueba.getVehiculosTipo("Albacete", "TURISMOS"));
			System.out.println(prueba.getVehiculosProvincia("Ceuta"));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
