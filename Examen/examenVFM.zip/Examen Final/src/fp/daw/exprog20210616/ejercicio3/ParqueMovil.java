package fp.daw.exprog20210616.ejercicio3;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class ParqueMovil {

	private static Map<String, Map<String, Integer>> mapa = new LinkedHashMap<String, Map<String, Integer>>();

		
	public ParqueMovil(String ruta, Integer anio) throws IOException {
		this.mapa = generaLista(ruta, anio);
	}
	

	public static Integer getVehiculosTipo(String provincia, String vehiculo) {
		Map<String, Integer> aux = mapa.get(provincia);
		return aux.get(vehiculo);
	}
	
	public static Integer getVehiculosProvincia(String provincia) {
		Map<String, Integer> aux = mapa.get(provincia);
		int sumatorio = 0;
		Iterator<Entry<String, Integer>> i = aux.entrySet().iterator();
		while (i.hasNext()) {
		 Entry<String, Integer> e = i.next();
		 sumatorio = e.getValue() + sumatorio;
		}
		return sumatorio;
	}
	
	public static Integer getTotalVehiculos(String vehiculo) {
		int sumatorio = 0;
		Iterator<Entry<String,Map<String,Integer>>> i = mapa.entrySet().iterator();
		while (i.hasNext()) {
			Entry<String,Map<String,Integer>> e = i.next();
			Map<String,Integer> aux = e.getValue();
			for (Entry<String, Integer> a: aux.entrySet()) {
				if (a.getKey().equals(vehiculo))
					sumatorio = a.getValue() + sumatorio;
			}
		}
		return sumatorio;
	}
	
	public static void guardaFichero(String ruta) {
		FileOutputStream fos = null;
		DataOutputStream out = null;
		try
		{
			File salida = new File (ruta);
			fos = new FileOutputStream(salida);
			out = new DataOutputStream(fos);

			Iterator<Entry<String,Map<String,Integer>>> i = mapa.entrySet().iterator();
			while (i.hasNext()) {
				Entry<String,Map<String,Integer>> e = i.next();
				out.writeBytes("PROVINCIA: " + e.getKey() + " - ");
				Map<String,Integer> aux = e.getValue();
				for (Entry<String, Integer> a: aux.entrySet()) {
					out.writeBytes("TIPO: " + a.getKey() +  " - N�: " + String.valueOf(a.getValue()) + " \n");
				}
			}
			out.close();
		} catch (FileNotFoundException e) {
	        System.out.println(e.getMessage());
	    } catch (EOFException e) {
	        System.out.println("Fin de fichero");
	    } catch (IOException e) {
	        System.out.println(e.getMessage());
	    } finally {
	        try {
	            if (fos != null) {
	                fos.close();
	            }
	            if (out != null) {
	                out.close();
	            }
	        } catch (IOException e) {
	            System.out.println(e.getMessage());                                                               
	        }
	    }
		
	}
	
	public Map<String, Map<String, Integer>> generaLista(String ruta, Integer anio) throws IOException {
		
		Map<String, Map<String, Integer>> mapa = new LinkedHashMap<String, Map<String, Integer>>();
		File in = new File (ruta);
		BufferedReader bri = new BufferedReader(new FileReader(in));
		String str= bri.readLine();
		String [] arrayTitulos = str.split(";");
		str= bri.readLine();
		while (str != null ) {
			Map<String, Integer> aux = new LinkedHashMap<String, Integer>();
//			System.out.println("Generando mapa vehiculos");
			String [] arrayLinea = str.split(";");
			for (int i=1; i < arrayLinea.length; i++) {
				aux.put(arrayTitulos[i],Integer.parseInt(arrayLinea[i]));
			}
//			System.out.println("Generando mapa ciudad");
			mapa.put(arrayLinea[0],aux);
			str= bri.readLine();
		}
		
		return mapa;
	}
	
	
	
}
